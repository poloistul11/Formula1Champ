## NOTICE

This repo will be deprecated once the new Chris Courses Node Auth series is released on YouTube.

The new series uses the custom Chris Courses web app framework, [Voyager](https://github.com/chriscourses/voyager), which is a much more robust and scalable solution than express-cc. Please check it out in the meantime during the wait for the new series.

## License

express-cc is an open-source framework running under the [MIT License](https://opensource.org/licenses/MIT).
